#! /usr/bin/env python
#A miniPython example

#! /usr/bin/env python
#A miniPython example

if x <3+2:
	print 3+2*3*4
